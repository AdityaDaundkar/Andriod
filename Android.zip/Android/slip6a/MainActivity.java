package com.example.slip6a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvResult;
    EditText etNum1,etNum2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
    }

    public void Addition(View v){
        float n1,n2,result;

        n1 = Float.parseFloat(etNum1.getText().toString());
        n2 = Float.parseFloat(etNum2.getText().toString());

        result = n1 + n2;

        tvResult.setText(String.format("Addition: %s", result));
    }
    public void Subtraction(View v){
        float n1,n2,result;

        n1 = Float.parseFloat(etNum1.getText().toString());
        n2 = Float.parseFloat(etNum2.getText().toString());

        result = n1 - n2;

        tvResult.setText(String.format("Subtraction: %s", result));
    }
    public void Multiplication(View v){
        float n1,n2,result;

        n1 = Float.parseFloat(etNum1.getText().toString());
        n2 = Float.parseFloat(etNum2.getText().toString());

        result = n1 * n2;

        tvResult.setText(String.format("Multiplication: %s", result));
    }
    public void Division(View v){
        float n1,n2,result;

        n1 = Float.parseFloat(etNum1.getText().toString());
        n2 = Float.parseFloat(etNum2.getText().toString());

        result = n1 / n2;

        tvResult.setText(String.format("Division: %s", result));
    }
}