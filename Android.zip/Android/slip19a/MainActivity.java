package com.example.slip19a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed1,ed2,ed3;
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.ed1);
        ed2=findViewById(R.id.ed2);
        ed3=findViewById(R.id.ed3);
        btn1=findViewById(R.id.btn1);

        btn1.setOnClickListener(view -> {
            String val1=ed1.getText().toString();
            String val2=ed2.getText().toString();
            //String val3=ed3.getText().toString();
            String ans=val1+val2;
            ed3.setText(ans);
        });
    }
}
