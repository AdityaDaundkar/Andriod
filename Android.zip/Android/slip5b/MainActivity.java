package com.example.slip5b;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edt_num;
    Button btnfact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt_num=(EditText) findViewById(R.id.edt_num);
        btnfact=(Button) findViewById(R.id.btnfact);
        btnfact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)  {fact();}

        });
    }
    private void fact(){
        int num = Integer.parseInt(edt_num.getText().toString());
        long fact = 1;
        for (int i=num;i>0;i--){
            fact=fact*i;
        }
        AlertDialog alertDialog=new AlertDialog.Builder(this)
                .setTitle("Factorial number")
                .setMessage("your factorial is:"+ fact)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();


    }
}