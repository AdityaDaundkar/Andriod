package com.example.slip3a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText  et_no=findViewById(R.id.et_no);
        Button bt_cal=findViewById(R.id.bt_cal);
        bt_cal.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Bundle bundle= new Bundle();
                int usr,fact=1,i;

                usr = Integer.parseInt(et_no.getText().toString());
                for (i = 1;i <= usr;i++)
                {
                    fact= fact*i;

                }

                bundle.putInt("key",fact);
                Intent intent=new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });
    }

}

