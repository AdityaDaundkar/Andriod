package com.example.slip9a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText f_name = findViewById(R.id.f_name);
        EditText l_name = findViewById(R.id.l_name);
        EditText address = findViewById(R.id.address);
        EditText ph_no = findViewById(R.id.ph_no);
        EditText email = findViewById(R.id.email);

        Button submit = findViewById(R.id.btn_submit);
        Button clear = findViewById(R.id.btn_clear);

        RadioButton male = findViewById(R.id.male);
        RadioButton female = findViewById(R.id.female);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = f_name.getText().toString();
                String name2 = l_name.getText().toString();
                String name3 = address.getText().toString();
                String name4 = ph_no.getText().toString();
                String name5 = email.getText().toString();
                String name6 = male.getText().toString();
                String name7 = female.getText().toString();
                showToast(name);
                showToast(name2);
                showToast(name3);
                showToast(name4);
                showToast(name5);
                showToast(name6);
                showToast(name7);
            }

            private void showToast(String text) {
                Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
            }
        });

        clear.setOnClickListener((View view) -> {
            f_name.getText().clear();
            l_name.getText().clear();
            address.getText().clear();
            ph_no.getText().clear();
            email.getText().clear();
        });

    }
}