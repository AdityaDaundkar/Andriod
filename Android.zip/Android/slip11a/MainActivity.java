package com.example.slip11a;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // These are the global variables
    RadioGroup radioGroup;
    RadioButton rb1,rb2,rb3,rb4,selectedRadioButton;
    Button buttonSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // layout instances
        buttonSubmit = (Button) findViewById(R.id.btnSubmit);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        rb1 = (RadioButton) findViewById(R.id.rb1);
        rb2 = (RadioButton) findViewById(R.id.rb2);
        rb3 = (RadioButton) findViewById(R.id.rb3);
        rb4 = (RadioButton) findViewById(R.id.rb4);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //Get the selected RadioButton
                selectedRadioButton = (RadioButton) findViewById(radioGroup.getCheckedRadioButtonId());
                // get RadioButton text
                String yourVote = selectedRadioButton.getText().toString();

                if (rb1.isChecked()) {
                    yourVote += rb1.getText().toString() + "\t TRUE\n";
                } else {
                    yourVote += rb1.getText().toString() + "\t FALSE\n";
                }

                if (rb2.isChecked()) {
                    yourVote += rb2.getText().toString() + "\t TRUE\n";
                } else {
                    yourVote += rb2.getText().toString() + "\t FALSE\n";
                }

                if (rb3.isChecked()) {
                    yourVote += rb3.getText().toString() + "\t TRUE\n";
                } else {
                    yourVote += rb3.getText().toString() + "\t FALSE\n";
                }
                if (rb4.isChecked()) {
                    yourVote += rb4.getText().toString() + "\t TRUE\n";
                } else {
                    yourVote += rb4.getText().toString() + "\t FALSE\n";
                }
                // display it as Toast to the user

                Toast.makeText(MainActivity.this, "Selected Radio Button is:" + yourVote+ "\n", Toast.LENGTH_LONG).show();

            }
        });
    }
}